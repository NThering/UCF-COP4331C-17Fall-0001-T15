package com.example.academicarticlemanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DownloadScreen extends AppCompatActivity {

    // ALL POPUP CODE IS DONE IN THE CLASS THAT CALLS THE POPUP!

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_screen);
    }
}
