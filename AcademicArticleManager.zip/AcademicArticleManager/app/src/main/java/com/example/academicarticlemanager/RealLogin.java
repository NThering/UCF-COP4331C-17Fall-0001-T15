package com.example.academicarticlemanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

public class RealLogin extends AppCompatActivity {

    Button loginButton, viewArticlesButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_login);

        loginButton = (Button) findViewById(R.id.loginButton);
        viewArticlesButton = (Button) findViewById(R.id.viewArticlesButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callPopup(v);
            }
        });

        viewArticlesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the articles
            }
        });
    }

    private void callPopup(View v) {
        LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_login_popup, null);

        final PopupWindow window = new PopupWindow(popupView, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        window.showAtLocation(v, Gravity.CENTER, 0, 0);

        EditText username = (EditText) popupView.findViewById(R.id.username_field);
        EditText password = (EditText) popupView.findViewById(R.id.password_field);
        Button register = (Button) popupView.findViewById(R.id.register);
        Button loginPopup = (Button) popupView.findViewById(R.id.loginButtonPopup);

        window.setFocusable(true);
        window.update();

        loginPopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // actually login
                Toast.makeText(getApplicationContext(), "Login works", Toast.LENGTH_SHORT).show();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // register
                Toast.makeText(getApplicationContext(), "Register works", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
